self.InChess = self.InChess || {};
self.InChess.engine = (function () {
    const T = self.InChess.tables;
    const R = self.InChess.rules;

    const vals = T.vals;
    const pst_p_w = T.pst_p_w;
    const pst_n = T.pst_n;
    const pst_b_w = T.pst_b_w;
    const pst_r_w = T.pst_r_w;
    const pst_q = T.pst_q;
    const pst_k_w = T.pst_k_w;
    const pst_k_e = T.pst_k_e;
    const pst_p_b = T.pst_p_b;
    const pst_b_b = T.pst_b_b;
    const pst_r_b = T.pst_r_b;
    const pst_k_w_b = T.pst_k_w_b;
    const pst_k_e_b = T.pst_k_e_b;
    const killerMoves = T.killerMoves;
    const historyTable = T.historyTable;
    const TT_EXACT = T.TT_EXACT, TT_ALPHA = T.TT_ALPHA, TT_BETA = T.TT_BETA;

    const transpositionTable = new Map();
    let currentNodes = 0;
    let moveCount = 0;
    let evalHistory = [];
    let boardHistory = [];

    function getBoardKey(grid) {
        return grid.map(r => r.join('')).join('/');
    }

    function evaluate(grid) {
        currentNodes++;
        let score = 0, tMat = 0;
        let wKr = -1, wKc = -1, bKr = -1, bKc = -1;
        let wB = 0, bB = 0;
        const wPawnCols = [0, 0, 0, 0, 0, 0, 0, 0], bPawnCols = [0, 0, 0, 0, 0, 0, 0, 0];
        const wRookCols = [], bRookCols = [];

        for (let r = 0; r < 8; r++) {
            for (let c = 0; c < 8; c++) {
                const p = grid[r][c];
                if (p === '.') continue;
                const idx = r * 8 + c;
                const isW = p === p.toUpperCase();
                const type = p.toLowerCase();
                let val = vals[type];

                if (type !== 'k') {
                    if (type !== 'p') tMat += val;
                    if (isW) {
                        if (type === 'p') { val += pst_p_w[idx]; wPawnCols[c]++; }
                        else if (type === 'n') val += pst_n[idx];
                        else if (type === 'b') { val += pst_b_w[idx]; wB++; }
                        else if (type === 'r') { val += pst_r_w[idx]; if (r === 1) val += 25; wRookCols.push(c); }
                        else if (type === 'q') val += pst_q[idx];
                        score += val;
                    } else {
                        if (type === 'p') { val += pst_p_b[idx]; bPawnCols[c]++; }
                        else if (type === 'n') val += pst_n[idx];
                        else if (type === 'b') { val += pst_b_b[idx]; bB++; }
                        else if (type === 'r') { val += pst_r_b[idx]; if (r === 6) val += 25; bRookCols.push(c); }
                        else if (type === 'q') val += pst_q[idx];
                        score -= val;
                    }
                } else {
                    if (isW) { wKr = r; wKc = c; } else { bKr = r; bKc = c; }
                }
            }
        }

        if (wKr === -1) return -25000;
        if (bKr === -1) return 25000;

        const isEg = tMat < 3000;
        score += isEg ? pst_k_e[wKr * 8 + wKc] : pst_k_w[wKr * 8 + wKc];
        score -= isEg ? pst_k_e_b[bKr * 8 + bKc] : pst_k_w_b[bKr * 8 + bKc];

        if (wB >= 2) score += 40;
        if (bB >= 2) score -= 40;

        for (let c of wRookCols) {
            if (wPawnCols[c] === 0) {
                score += (bPawnCols[c] === 0) ? 25 : 15;
            }
        }
        for (let c of bRookCols) {
            if (bPawnCols[c] === 0) {
                score -= (wPawnCols[c] === 0) ? 25 : 15;
            }
        }

        for (let i = 0; i < 8; i++) {
            if (wPawnCols[i] > 1) score -= 18;
            if (bPawnCols[i] > 1) score += 18;
            if (wPawnCols[i] > 0 && (i === 0 || wPawnCols[i - 1] === 0) && (i === 7 || wPawnCols[i + 1] === 0)) score -= 15;
            if (bPawnCols[i] > 0 && (i === 0 || bPawnCols[i - 1] === 0) && (i === 7 || bPawnCols[i + 1] === 0)) score += 15;
        }

        if (!isEg) {
            if (wKr >= 6 && wKc >= 5) {
                if (grid[6][5] !== 'P') score -= 15;
                if (grid[6][6] !== 'P') score -= 25;
                if (grid[6][7] !== 'P') score -= 15;
            }
            if (bKr <= 1 && bKc >= 5) {
                if (grid[1][5] !== 'p') score += 15;
                if (grid[1][6] !== 'p') score += 25;
                if (grid[1][7] !== 'p') score += 15;
            }
        }

        for (let r = 0; r < 8; r++) {
            for (let c = 0; c < 8; c++) {
                const p = grid[r][c];
                if (p === 'P') {
                    let passed = true;
                    for (let checkR = r - 1; checkR >= 0; checkR--) {
                        for (let checkC = Math.max(0, c - 1); checkC <= Math.min(7, c + 1); checkC++) {
                            if (grid[checkR][checkC] === 'p') { passed = false; break; }
                        }
                        if (!passed) break;
                    }
                    if (passed) score += (7 - r) * (isEg ? 25 : 12);
                } else if (p === 'p') {
                    let passed = true;
                    for (let checkR = r + 1; checkR < 8; checkR++) {
                        for (let checkC = Math.max(0, c - 1); checkC <= Math.min(7, c + 1); checkC++) {
                            if (grid[checkR][checkC] === 'P') { passed = false; break; }
                        }
                        if (!passed) break;
                    }
                    if (passed) score -= r * (isEg ? 25 : 12);
                }
            }
        }

        return score;
    }

    function qSearch(grid, alpha, beta, isW, depth = 0) {
        const standPat = isW ? evaluate(grid) : -evaluate(grid);
        if (standPat >= beta) return beta;
        if (alpha < standPat) alpha = standPat;

        if (depth > 8) return alpha;

        const moves = R.genMoves(grid, isW, true);
        moves.sort((a, b) => b.cS - a.cS);

        for (const m of moves) {
            const vic = (grid[m.nr][m.nc] || 'p').toLowerCase();
            if (standPat + vals[vic] + 250 < alpha && !m.promo) continue;

            const { undo } = R.makeMove(grid, m, isW, '-');
            if (R.isInCheck(grid, isW)) {
                R.unmakeMove(grid, m, undo);
                continue;
            }

            const score = -qSearch(grid, -beta, -alpha, !isW, depth + 1);
            R.unmakeMove(grid, m, undo);

            if (score >= beta) return beta;
            if (score > alpha) alpha = score;
        }
        return alpha;
    }

    function minimax(grid, depth, alpha, beta, isW, castling = "-", ep = "-", ply = 0) {
        const hash = R.computeHash(grid, isW, castling, ep);
        const cached = transpositionTable.get(hash);
        let ttMove = null;

        if (cached) {
            ttMove = cached.move;
            let score = cached.score;
            if (score > 15000) score -= ply;
            else if (score < -15000) score += ply;

            if (cached.depth >= depth) {
                if (cached.flag === TT_EXACT) return score;
                if (cached.flag === TT_ALPHA && score <= alpha) return alpha;
                if (cached.flag === TT_BETA && score >= beta) return beta;
            }
        }

        const inCheck = R.isInCheck(grid, isW);
        if (inCheck && ply < 6) depth++;

        if (depth <= 0 && !inCheck) return qSearch(grid, alpha, beta, isW);

        const moves = R.genMoves(grid, isW, false, castling, ep);

        const killer1 = killerMoves[ply] ? killerMoves[ply][0] : null;
        const killer2 = killerMoves[ply] ? killerMoves[ply][1] : null;

        for (const m of moves) {
            if (ttMove && m.r === ttMove.r && m.c === ttMove.c && m.nr === ttMove.nr && m.nc === ttMove.nc && m.promo === ttMove.promo) {
                m.orderScore = 10000000;
            } else if (m.cap) {
                m.orderScore = 1000000 + m.cS;
            } else if (killer1 && m.r === killer1.r && m.c === killer1.c && m.nr === killer1.nr && m.nc === killer1.nc) {
                m.orderScore = 900000;
            } else if (killer2 && m.r === killer2.r && m.c === killer2.c && m.nr === killer2.nr && m.nc === killer2.nc) {
                m.orderScore = 800000;
            } else {
                m.orderScore = historyTable[m.r * 8 + m.c][m.nr * 8 + m.nc] + (m.cS || 0);
            }
        }
        moves.sort((a, b) => b.orderScore - a.orderScore);

        let bestScore = -Infinity;
        let bestMove = null;
        const oldAlpha = alpha;
        let legalMoves = 0;

        for (let i = 0; i < moves.length; i++) {
            const m = moves[i];
            const { undo, newCastling } = R.makeMove(grid, m, isW, castling);
            if (R.isInCheck(grid, isW)) {
                R.unmakeMove(grid, m, undo);
                continue;
            }
            legalMoves++;

            const newEp = (undo.p && undo.p.toLowerCase() === 'p' && Math.abs(m.nr - m.r) === 2) ?
                String.fromCharCode(97 + m.c) + (isW ? 3 : 6) : '-';

            let score;
            if (depth >= 3 && legalMoves > 4 && !m.cap && !inCheck && !m.promo && !m.isCastle && alpha > -10000) {
                score = -minimax(grid, depth - 2, -alpha - 1, -alpha, !isW, newCastling, newEp, ply + 1);
                if (score > alpha) {
                    score = -minimax(grid, depth - 1, -beta, -alpha, !isW, newCastling, newEp, ply + 1);
                }
            } else {
                score = -minimax(grid, depth - 1, -beta, -alpha, !isW, newCastling, newEp, ply + 1);
            }

            R.unmakeMove(grid, m, undo);

            if (score > bestScore) {
                bestScore = score;
                bestMove = m;
            }
            if (score > alpha) alpha = score;
            if (alpha >= beta) {
                if (!m.cap && ply < 32) {
                    killerMoves[ply][1] = killerMoves[ply][0];
                    killerMoves[ply][0] = m;
                    historyTable[m.r * 8 + m.c][m.nr * 8 + m.nc] += depth * depth;
                }
                break;
            }
        }

        if (legalMoves === 0) {
            if (inCheck) return -25000 + ply;
            return 0;
        }

        let flag = TT_EXACT;
        if (bestScore <= oldAlpha) flag = TT_ALPHA;
        else if (bestScore >= beta) flag = TT_BETA;

        let ttScore = bestScore;
        if (bestScore > 15000) ttScore += ply;
        else if (bestScore < -15000) ttScore -= ply;

        transpositionTable.set(hash, { score: ttScore, depth, flag, move: bestMove });
        if (transpositionTable.size > 250000) transpositionTable.clear();

        return bestScore;
    }

    async function analyzeEngine(fen, myColor, tabId, activeAnalysis, engineSettings) {
        if (activeAnalysis.get(tabId) !== fen) return;

        currentNodes = 0;
        chrome.tabs.sendMessage(tabId, { type: 'SHOW_NOTIFICATION', notifType: 'calc', text: 'Думаю...', persist: true });

        const p = fen.split(' ');
        const isW = p[1] === 'w';
        const castling = p[2] || "-";
        const ep = p[3] || "-";
        const grid = p[0].split('/').map(r => {
            const row = [];
            for (let c of r) {
                if (/[1-8]/.test(c)) { for (let j = 0; j < parseInt(c); j++) row.push('.'); }
                else row.push(c);
            }
            return row;
        });

        const rootEval = isW ? evaluate(grid) : -evaluate(grid);

        let maxDepth;
        if (engineSettings.depth && engineSettings.depth !== 'auto') {
            maxDepth = parseInt(engineSettings.depth) || 5;
        } else {
            maxDepth = 5;
            let tMat = 0;
            for (let r of grid) for (let c of r) if (c !== '.' && c.toLowerCase() !== 'k' && c.toLowerCase() !== 'p') tMat += vals[c.toLowerCase()];
            if (tMat < 3000) maxDepth = 6;
            if (tMat < 1500) maxDepth = 7;
        }

        let bestMoveUCI = null;
        let allMovesEvals = [];
        let lastThoughtTime = 0;

        for (let i = 0; i < killerMoves.length; i++) {
            killerMoves[i][0] = null;
            killerMoves[i][1] = null;
        }
        for (let i = 0; i < 64; i++) {
            for (let j = 0; j < 64; j++) {
                historyTable[i][j] >>= 1;
            }
        }

        for (let d = 1; d <= maxDepth; d++) {
            const moves = R.genMoves(grid, isW, false, castling, ep);

            if (bestMoveUCI) {
                moves.sort((a, b) => {
                    const uciA = R.toUCI(a);
                    const uciB = R.toUCI(b);
                    if (uciA === bestMoveUCI) return -1;
                    if (uciB === bestMoveUCI) return 1;
                    return (b.cS || 0) - (a.cS || 0);
                });
            }

            allMovesEvals = [];
            for (const m of moves) {
                const moveUCI = R.toUCI(m);

                const now = Date.now();
                if (engineSettings.thoughts !== false && (now - lastThoughtTime > 75)) {
                    lastThoughtTime = now;
                    chrome.tabs.sendMessage(tabId, { type: 'THOUGHT_MOVE', uci: moveUCI });
                }

                const { undo, newCastling } = R.makeMove(grid, m, isW, castling);
                if (R.isInCheck(grid, isW)) {
                    R.unmakeMove(grid, m, undo);
                    continue;
                }

                let v = -minimax(grid, d - 1, -Infinity, Infinity, !isW, newCastling, ep, 1);

                const nKey = getBoardKey(grid);
                const repeats = boardHistory.filter(h => h === nKey).length;
                if (repeats >= 1) v -= 500;
                if (repeats >= 2) v -= 5000;

                R.unmakeMove(grid, m, undo);

                if (activeAnalysis.get(tabId) !== fen) return;

                allMovesEvals.push({ uci: moveUCI, eval: v, m });
            }

            if (allMovesEvals.length === 0) break;

            allMovesEvals.sort((a, b) => b.eval - a.eval);
            bestMoveUCI = allMovesEvals[0].uci;

            if (activeAnalysis.get(tabId) !== fen) return;
            const currentEval = isW ? allMovesEvals[0].eval : -allMovesEvals[0].eval;
            chrome.tabs.sendMessage(tabId, { type: 'UPDATE_EVAL', evalScore: currentEval });
            chrome.tabs.sendMessage(tabId, { type: 'UPDATE_CALC', text: `Глубина ${d} | Узлы: ${currentNodes}` });
            await new Promise(r => setTimeout(r, 0));
        }

        chrome.tabs.sendMessage(tabId, { type: 'CLEAR_THOUGHT' });

        if (allMovesEvals.length === 0) {
            chrome.tabs.sendMessage(tabId, { type: 'SHOW_NOTIFICATION', notifType: 'info', text: 'Нет легальных ходов!', persist: false });
            return;
        }

        const bM = allMovesEvals[0];
        const aM = allMovesEvals[1];
        let isBrill = aM && (bM.eval - aM.eval) >= 200;

        let reason = "Оптимальный ход";
        if (bM.eval >= 20000) reason = "Мат!";
        else if (isBrill) reason = "Блестящий ход!";
        else if (bM.m.cap) reason = "Забираем фигуру";
        else if (bM.eval > rootEval + 50) reason = "Улучшаем позицию";

        const threats = R.computeThreats(grid, isW);
        const finalEval = isW ? bM.eval : -bM.eval;

        const res = {
            best: bM.uci,
            alt1: allMovesEvals[1] ? allMovesEvals[1].uci : null,
            alt2: allMovesEvals[2] ? allMovesEvals[2].uci : null,
            isBrill,
            evalScore: finalEval,
            threats,
            predict: null
        };

        if (activeAnalysis.get(tabId) !== fen) return;

        if (engineSettings.predicts && bM && bM.m) {
            try {
                const { undo, newCastling } = R.makeMove(grid, bM.m, isW, castling);
                if (!R.isInCheck(grid, isW)) {
                    const oppMoves = R.genMoves(grid, !isW, false, newCastling, ep);
                    let oppBest = null;
                    let oppBestScore = -Infinity;
                    for (const om of oppMoves) {
                        const { undo: u2, newCastling: nc2 } = R.makeMove(grid, om, !isW, newCastling);
                        if (R.isInCheck(grid, !isW)) { R.unmakeMove(grid, om, u2); continue; }
                        const v = -minimax(grid, 2, -Infinity, Infinity, isW, nc2, ep, 1);
                        R.unmakeMove(grid, om, u2);
                        if (v > oppBestScore) { oppBestScore = v; oppBest = om; }
                    }
                    if (oppBest) res.predict = R.toUCI(oppBest);
                }
                R.unmakeMove(grid, bM.m, undo);
            } catch (e) { }
        }

        if (activeAnalysis.get(tabId) !== fen) return;

        chrome.tabs.sendMessage(tabId, { type: 'DRAW_MOVE', moves: res });
        chrome.tabs.sendMessage(tabId, {
            type: 'SHOW_NOTIFICATION',
            notifType: isBrill ? 'info' : 'success',
            text: `<span class="move-text">${res.best}</span> - ${reason}`,
            persist: false
        });

        if (engineSettings.auto) {
            chrome.tabs.sendMessage(tabId, { type: 'AUTO_MOVE', uci: res.best, sourceFen: fen });
        }

        moveCount++;
        const relEval = rootEval;
        evalHistory.push(relEval);

        if (moveCount % 5 === 0 && moveCount > 0) {
            let wMat = 0, bMat = 0;
            for (let r = 0; r < 8; r++) {
                for (let c = 0; c < 8; c++) {
                    const pc = grid[r][c];
                    if (pc !== '.') {
                        const t = pc.toLowerCase();
                        if (t !== 'k') {
                            const v = vals[t] || 0;
                            if (pc === pc.toUpperCase()) wMat += v;
                            else bMat += v;
                        }
                    }
                }
            }

            const matDiff = myColor === 'w' ? wMat - bMat : bMat - wMat;
            const lastFive = evalHistory.slice(-5);
            const trend = lastFive[lastFive.length - 1] - lastFive[0];

            let verdict;
            if (relEval > 300) verdict = 'Вы доминируете';
            else if (relEval > 100) verdict = 'У вас преимущество';
            else if (relEval > -100) verdict = 'Равная игра';
            else if (relEval > -300) verdict = 'Противник давит';
            else verdict = 'Противник доминирует';

            let trendStr = trend > 50 ? 'Улучшение' : (trend < -50 ? 'Ухудшение' : 'Стабильно');
            const matStr = matDiff > 0 ? `+${matDiff}` : `${matDiff}`;
            const evalStr = relEval > 0 ? `+${(relEval / 100).toFixed(1)}` : `${(relEval / 100).toFixed(1)}`;

            const statsText = `${verdict} | ${evalStr} | Мат: ${matStr} | ${trendStr}`;

            setTimeout(() => {
                if (activeAnalysis.get(tabId) === fen) {
                    chrome.tabs.sendMessage(tabId, {
                        type: 'SHOW_NOTIFICATION',
                        notifType: 'info',
                        text: statsText,
                        persist: false
                    });
                }
            }, 5000);
        }
    }

    function pushBoardKey(key) {
        boardHistory.push(key);
        if (boardHistory.length > 50) boardHistory.shift();
    }

    return { evaluate, analyzeEngine, getBoardKey, pushBoardKey };
})();