# InChess Android — starter project

Android Studio project (Kotlin + WebView), package `com.inchess.trainer`.

## Open/build
1. Open this folder in Android Studio (Hedgehog or newer).
2. Allow Gradle sync and install Android SDK Platform 35 (or change `compileSdk` / `targetSdk` to an installed SDK).
3. Build > Build Bundle(s) / APK(s) > Build APK(s).

## What's included
- Minimal Android app shell.
- FEN syntax validation and PGN text import placeholder for an offline training workflow.
- Full original InChess extension source copied to `app/src/main/assets/inchess/original/`, including its JS engine/rules/tables, UI, icons, and voice assets.

## Important integration notes
The original extension is a Manifest V3 Chrome extension. Android WebView does not implement `chrome.runtime`, `chrome.storage`, service workers for extensions, or extension content-script injection. The original source is preserved, but it is **not yet wired into the Android screen**. To complete the port, implement an Android-native bridge for settings/messages, port the background engine lifecycle, and connect a legal offline training-position provider. This project intentionally does not inspect or overlay live rated Chess.com games or automate moves.

## Source layout
- `app/src/main/java/.../MainActivity.kt` — Android shell.
- `app/src/main/assets/index.html` — training UI starter.
- `app/src/main/assets/inchess/original/` — original extension files and media.
